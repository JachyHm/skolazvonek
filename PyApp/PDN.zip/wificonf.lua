SSID="EMtest"
HESLO="13znakudlouhe"
--					NIZE UVEDENE NECHAT ZAKOMENTOVANE!
-- IPadresa="192.168.12.68"		tady bude casem dodelana pevna IP adresa
-- MASKAsite="192.168.12.1"		takze se nebude muset NodeMCU
-- BRANAsite="255.255.255.0"	pred nahranim vyhledavat v siti